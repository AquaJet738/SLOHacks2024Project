# Amazon EcoFriend
###  A browser extension that recommends eco friendly and sustainable alternatives to amazon products.

### Installation
#### Clone the repo and cd into it
#### Install required libraries using `pip install -r requirements.txt`

### Usage
#### Start the backend flask server by running `python  api/index.py`
#### Load the `extension` folder as an unpacked extension on the browser manage extensions page
#### The extension will now automatically run everytime you visit an Amazon product page
